package Classes;


/**
 * Classe Salas;
 * 
 * Diz respeito a todos os requisitos correspondentes a Salas no sistema;
 * Fun��o correspondente: cadastro de salas;
 * 
 */


import java.util.ArrayList;
import java.util.List;
import java.util.Scanner;

public class Salas {

	/**
	 * A var�avel "nomeSala" armazena o nome das salas da fase 1, cadastrado pelo usu�rio no sistema ; 
	 */	

	public String nomeSala;
	
	/**
	 * A var�avel "nomeSala2" armazena o nome das salas da fase 2, cadastrado pelo usu�rio no sistema ; 
	 */	
	
	public String nomeSala2;
	
	/**
	 * A var�avel "consultar" armazena o nome da sala  da fase 1 e fase 2, na fun��o de consulta de cada sala
	 * cadastrada pelo usu�rio; 
	 */	
	
	public String consultar;
	
	/**
	 * A var�avel "selecao" corresponde aos n�meros do switch de determinada fun��o; 
	 * 
	 */	
	
	int selecao;

	/**
	 * O ArrayList Sala1 � o local que armazena os dados das salas cadastradas na fase 1; 
	 *    
	 */

	List<String> Sala1 = new ArrayList<String>();
	
	/**
	 * O ArrayList Sala1 � o local que armazena os dados das salas cadastradas na fase 2; 
	 *    
	 */
	
	List<String> Sala2 = new ArrayList<String>();
			
	
	/**
	 * A vari�vel Scanner inU � respons�vel por fazer a leituta dos dados digitados pelo usu�rio;  
	 */

	Scanner inU = new Scanner(System.in);

	public String getNomeSala() {
		return nomeSala;
	}

	public void setNomeSala(String nomeSala) {
		this.nomeSala = nomeSala;

	}

	public String getNomeSala2() {
		return nomeSala2;
	}

	public void setNomeSala2(String nomeSala2) {
		this.nomeSala2 = nomeSala2;
	}

	/**
	 * A Lista "listagemSala1" � respons�vel por armazenar os dados do ArrayList Sala1; 
	 * 
	 * As condicionais if setam fun��es correspondentes a cada switch referente 
	 * �s salas da fase 1 (ArrayList "Sala1");
	 *  
	 * @param selecao
	 * @return Sala1
	 */
	
	public List<String> listagemSala1(int selecao)

	{  
		/**
		 * A sele��o 14 diz respeito ao cadastro de salas na fase 1 no sistema, onde cada nome
		 * digitado pelo usu�rio � adicionado ao ArrayList "Sala1"
		 */

		if (selecao == 14) {

			Sala1.add(getNomeSala());
			System.out.println("\nAdicionado com sucesso!");
		
		}	return Sala1;
		
   } 
	
	/**
	 * A Lista "listagemSala2" � respons�vel por armazenar os dados do ArrayList Sala2; 
	 * 
	 * As condicionais if setam fun��es correspondentes a cada switch referente 
	 * �s salas da fase 2 (ArrayList "Sala2");
	 *  
	 * @param selecao
	 * @return Sala2
	 */
    
	public List<String> listagemSala2(int selecao)

	{  
		/**
		 * A sele��o 15 diz respeito ao cadastro de salas na fase 2 no sistema, onde cada nome
		 * digitado pelo usu�rio � adicionado ao ArrayList "Sala2"
		 */

		if (selecao == 15) {

			Sala2.add(getNomeSala2());
			System.out.println("\nAdicionado com sucesso!");
		
		}		
		
				return Sala2; 
				
	}
}
