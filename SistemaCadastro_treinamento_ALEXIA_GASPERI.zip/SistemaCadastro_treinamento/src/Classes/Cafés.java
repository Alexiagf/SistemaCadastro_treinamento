package Classes;


/**
 * Classe Caf�s;
 * 
 * Diz respeito a todos os requisitos correspondentes aos Caf�s no sistema;
 * Fun��o correspondente: cadastro de caf�s;
 * 
 */

import java.util.ArrayList;
import java.util.List;
import java.util.Scanner;

public class Caf�s {

	/**
	 * A var�avel "nomeCaf�" armazena o nome dos caf�s da fase 1, cadastrado pelo usu�rio no sistema; 
	 */	

	public String nomeCaf�;

	/**
	 * A var�avel "nomeCaf�2" armazena o nome dos caf�s da fase 2, cadastrado pelo usu�rio no sistema; 
	 */	

	public String nomeCaf�2;

	/**
	 * A var�avel "consultar" armazena o nome do caf�  da fase 1 e fase 2, na fun��o de consulta de cada caf�
	 * cadastrado pelo usu�rio; 
	 */	

	public String consultar;

	/**
	 * A var�avel "selecao" corresponde aos n�meros do switch de determinada fun��o; 
	 * 
	 */	

	int selecao;


	/**
	 * O ArrayList Caf�1 � o local que armazena os dados dos caf�s cadastrados na fase 1; 
	 *    
	 */

	List<String> Caf�1 = new ArrayList<String>();

	/**
	 * O ArrayList Caf�2 � o local que armazena os dados dos caf�s cadastrados na fase 2; 
	 *    
	 */

	List<String> Caf�2 = new ArrayList<String>();

	/**
	 * A vari�vel Scanner inU � respons�vel por fazer a leituta dos dados digitados pelo usu�rio;  
	 */

	Scanner inU = new Scanner(System.in);

	public String getNomeCaf�() {
		return nomeCaf�;
	}

	public void setNomeCaf�(String nomeCaf�) {
		this.nomeCaf� = nomeCaf�;

	}

	public String getNomeCaf�2() {
		return nomeCaf�2;
	}

	public void setNomeCaf�2(String nomeCaf�2) {
		this.nomeCaf�2 = nomeCaf�2;
	}

	/**
	 * A Lista "listagemCaf�1" � respons�vel por armazenar os dados do ArrayList Caf�1; 
	 * 
	 * As condicionais if setam fun��es correspondentes a cada switch referente 
	 * aos caf�s da fase 1 (ArrayList "Caf�1");
	 *  
	 * @param selecao
	 * @return Caf�1
	 */

	public List<String> listagemCaf�1(int selecao)

	{  
		/**
		 * A sele��o 16 diz respeito ao cadastro de caf�s na fase 1 no sistema, onde cada nome
		 * digitado pelo usu�rio � adicionado ao ArrayList "Caf�1"
		 */

		if (selecao == 16) {
			Caf�1.add(getNomeCaf�());
			System.out.println("\nAdicionado com sucesso!");
		}return Caf�1;
	}	

	/**
	 * A Lista "listagemCaf�2" � respons�vel por armazenar os dados do ArrayList Caf�2; 
	 * 
	 * As condicionais if setam fun��es correspondentes a cada switch referente 
	 * aos caf�s da fase 2 (ArrayList "Caf�2");
	 *  
	 * @param selecao
	 * @return Caf�2
	 */		

	public List<String> listagemCaf�2(int selecao)

	{  
		/**
		 * A sele��o 17 diz respeito ao cadastro de caf�s na fase 2 no sistema, onde cada nome
		 * digitado pelo usu�rio � adicionado ao ArrayList "Caf�2"
		 */

		if (selecao == 17) {

			Caf�2.add(getNomeCaf�2());
			System.out.println("\nAdicionado com sucesso!");

		}	return Caf�2;

	}
}
